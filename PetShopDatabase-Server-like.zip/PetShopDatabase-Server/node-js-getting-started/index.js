var express = require('express');
var app = express();
app.set('port', (process.env.PORT || 5000));

var bodyParser = require("body-parser");
app.use(bodyParser.json()); //soporte para codificar json
app.use(bodyParser.urlencoded({extended:true })) //soporte para decodificar las urls;

var firebase = require("firebase");
firebase.initializeApp({
  serviceAccount: "PetShopFirebase-a79712384f6d.json",
  databaseURL: "https://petshopfirebase.firebaseio.com"
});

var FCM = require('fcm-push');

app.use(express.static(__dirname + '/public'));

// views is directory for all template files
app.set('views', __dirname + '/views');
app.set('view engine', 'ejs');

app.get('/', function(request, response) {
  response.render('pages/index');
});

//POST
//https://lit-citadel-90938.herokuapp.com/
//https://lit-citadel-90938.herokuapp.com/registrar-usuario
//id_dispositivo
//id_usuario_instagram
//id_picture
app.post('/registrar-usuario', function(request, response){

    var token 	= request.body.token;
	var id_usuario_instagram 	= request.body.id_usuario_instagram;
	var id_picture = request.body.id_picture;
	
	var db = firebase.database();
	
	var regUsuario = db.ref('registrar-usuario').push();
	regUsuario.set({
		token: token,
		id_usuario_instagram: id_usuario_instagram,
		id_picture: id_picture
	});	
	
	var path = regUsuario.toString(); //https://lit-citadel-90938.herokuapp.com/registrar-usuario/-KJlTaOQPwP-ssImryV1
	var pathSplit = path.split('registrar-usuario/')
	var idAutoGenerado = pathSplit[1];

	var respuesta = generarRespuestaAToken(db, idAutoGenerado);
	response.setHeader("Content-Type", "application/json");
	response.send(JSON.stringify(respuesta)); 
    
});


function generarRespuestaAToken(db, idAutoGenerado) {
	var respuesta = {};
	var usuario = "";
	var ref = db.ref("registrar-usuario");
	ref.on("child_added", function(snapshot, prevChildKey) {
		usuario = snapshot.val();
		respuesta = {
			id: idAutoGenerado,
			token: usuario.token,
			id_usuario_instagram: usuario.id_usuario_instagram,
			id_picture: usuario.id_picture
		};
	});
	return respuesta;
}

//GET
//https://lit-citadel-90938.herokuapp.com/like-foto/:id/:id_ususario_instagram
//id
//id_usuario_instagram
//token



app.get('/like-foto/:id/:id_usuario_instagram', function(request, response){

   var id = request.params.id;
   var id_usuario_instagram = request.params.id_usuario_instagram;
   
   var db = firebase.database();
   var ref = db.ref('registrar-usuario/' + id);
   var usuario ="";   
   var respuesta= {};
   // Attach an asynchronous callback to read the data at our posts reference
    ref.on("value", function(snapshot) {
        	usuario = snapshot.val();
        	var mensaje = id_usuario_instagram + " Te dio un Like ";
        	enviarNotificacion(usuario.token, mensaje);
        	respuesta = {
                id: id,
                token: usuario.token,
                id_usuario_instagram: usuario.id_usuario_instagram  
            };
            response.send(JSON.stringify(respuesta)); 
            
    
    }, function (errorObject) {
        console.log("The read failed: " + errorObject.code);
        respuesta = {
                id: "",
                token: "",
                id_usuario_instagram: ""  
        };
       response.send(JSON.stringify(respuesta)); 
                  
    });
});

//funcion de notificacion

function enviarNotificacion(tokenDestinatario, mensaje){
    var serverKey = 'AIzaSyBuVpjRBVUyB9wjTzkCC0BYQ87Fio2VtdE';
    var fcm = new FCM(serverKey);
    
    var message = {
    to: tokenDestinatario, // required fill with device token or topics
    collapse_key: '', 
    data: {},
    notification: {
        title: 'Notificacion desde servidor',
        body: mensaje,
        sound: "default",
        color: "#00BCD4"
    }
};

//callback style
fcm.send(message, function(err, response){
    if (err) {
        console.log("Something has gone wrong!");
    } else {
        console.log("Successfully sent with response: ", response);
    }
});

//promise style
fcm.send(message)
    .then(function(response){
        console.log("Successfully sent with response: ", response);
    })
    .catch(function(err){
        console.log("Something has gone wrong!");
        console.error(err);
    })
    
};

app.listen(app.get('port'), function() {
  console.log('Node app is running on port', app.get('port'));
});
